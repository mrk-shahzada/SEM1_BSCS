#include<iostream>
using namespace std;
int main(){
    for (int i = 9; i >= 1; i--)
    {
        for (int j = 1; j < i ; j++)
        {
            cout<<" ";
        }
        for (int k = 1; k <= 10-i; k++)
        {
            cout<<k;
        }
        for (int l = 10-i-1; l >= 1; l--)
        {   
            cout<<l;
        }
        cout<<endl;
    }

     for(int i=1;i<=9;i++){

    for(int j=1;j<=i;j++)
    cout<<" ";
    for(int k=1;k<=9-i;k++)
    {
        cout<<k;
    }
    cout<<endl;
    }
    
return 0;
}