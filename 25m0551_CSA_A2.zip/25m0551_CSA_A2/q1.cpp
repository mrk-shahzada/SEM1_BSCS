//Muhammad Rowaifa Khan
//25M-0551
//Assignment no 2

#include<iostream>
using namespace std;
int main(){
    int n,packets;
    cout<<"Enter total  number of eggs :";
    cin>>n;

    packets = n/30;
    cout<<"\nNumber of 30 eggs packing: "<<packets;
    packets = n%30;
    cout<<"\nNumber of 30 eggs packing: "<<packets<<endl;

    packets = n/24;
    cout<<"\nNumber of 30 eggs packing: "<<packets;
    packets = n%24;
    cout<<"\nNumber of 30 eggs packing: "<<packets<<endl;

    packets = n/18;
    cout<<"\nNumber of 30 eggs packing: "<<packets;
    packets = n%18;
    cout<<"\nNumber of 30 eggs packing: "<<packets<<endl;

    packets = n/12;
    cout<<"\nNumber of 30 eggs packing: "<<packets;
    packets = n%12;
    cout<<"\nNumber of 30 eggs packing: "<<packets<<endl;

    packets = n/6;
    cout<<"\nNumber of 30 eggs packing: "<<packets;
    packets = n%6;
    cout<<"\nNumber of 30 eggs packing: "<<packets<<endl;
return 0;
}