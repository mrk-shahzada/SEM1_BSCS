//Muhammad Rowaifa Khan
//25M-0551
//Assignment no 2
#include<iostream>
using namespace std;
int main(){
        int work_days, salary;
        cout<<"Enter the number of days you worked: ";
        cin>>work_days;

        if(work_days>=25 && work_days<=30){
            cout<<"Your are Full Time Employee"<<endl;
            salary = 900*8*work_days*0.05;
            cout<<"Your Salary is: "<<salary<<endl;
        }
        if (work_days>=15 && work_days<=24){
            cout<<"You are Part time Employee"<<endl;
            salary = 850*8*work_days*0.07;
            cout<<"Your Salary is: "<<salary<<endl;
        }
        if (work_days<15)
        {
            cout<<"You are Adhoc"<<endl;
            salary = 600*8*work_days*0.10;
            cout<<"Your Salary is: "<<salary<<endl;
        }
        
        
        
return 0;
}