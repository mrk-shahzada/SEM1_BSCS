//Muhammad Rowaifa Khan
//25M-0551
//Assignment no 2
#include<iostream>
#include<iomanip>
#include<string>
using namespace std;
int main(){
    string connect_date = "28 Dec 11";
    int ED = 0;
    string bill_month = "Oct 21";
    string reading_date = "02-Nov-21";
    string issue_date = "03-Nov-21";
    string due_date = "17-Nov-21";
    string consumer_Id = "16112005";
    string tarrif = "A-1a(01)";
    int load = 2;
    int oldAccNumber = 0;
    string division = "Westridge";
    string sub_division = "Tarnol Pesh RD";
    string feeder_name = "NUST Road";
    string reference_num;
    string name;
    string address;
    int meter_num = 123456;
    int previous = 9742;
    int present = 9942;
    int MF = 1;
    int units_consumed;
    
    cout<<"Enter your name :";
    getline(cin,name);
    cout<<"\nEnter Your Address :";
    getline(cin,address);
    cout<<"\nEnter you Reference Number (Roll-Number) :";
    getline(cin,reference_num);
    cout<<"\nEnter Your Consumed Units :";
    cin>>units_consumed;

    int cost_per_unit = 20;
    int cost_of_enlectricity = cost_per_unit * units_consumed;
    int fuel_price_adjustment = 700;
    int FC_Surcharge = 90;
    int QTR_Tarrif = -14;
    int Total1 = cost_of_enlectricity + fuel_price_adjustment + FC_Surcharge + QTR_Tarrif;
    int TV_fee = 35;
    int GST = 800;
    int GST_ON_FPA = 108;
    int Total2 = TV_fee + GST + GST_ON_FPA;
    int current_bill = Total1 + Total2;
    int total_FPA = 700;
    int payable_within_due_date = current_bill + total_FPA;
    int LP_surcharge = 400;
    int payable_after_due_date = payable_within_due_date + LP_surcharge;




 cout<<"-----Your Electricity Bill Details-----"<<endl;

    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|   Connection Date |   ED   |   Month of Bill   |   Reading Date   |   Issue Date   |   Due Date   |"<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<"|   "<<connect_date<<"       |      "<<ED<<"  |      "<<bill_month<<"    |     "<<reading_date<<"    |     "<<issue_date<<"    |     "<<due_date<<"  |"<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|   Consumer Id  |  Tarrif  |  Load  |  Old A/C Number  |  Division  |"<<division<<"  |"<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<"|  "<<consumer_Id<<"      |  "<<tarrif<<" |  "<<oldAccNumber<<"    |  Sub-Division  |  "<<sub_division<<"  |"<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|  Reference Number  |  Lock Age  |  No of Acs  |  UN-Bill-Age  |  Feeder Name  |  "<<feeder_name<<"  |"<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<"|  "<<reference_num<<"           |             |           |          |         |"<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|  Name & Address\tSay No To Corruption\t|\n|"<<name<<"\t\t\t|\n|"<<address<<"\t\t\t|"<<endl;         
    cout<<"___________________________________________________________________________________________________"<<endl;                           
    cout<<left<<setw(25)<<"|  Meter Number  |   Previous   |   Present   |   MF   |   Units   |  "<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<"|  "<<meter_num<<"        |  "<<previous<<"      |    "<<present<<"      |    "<<MF<<"      |    "<<units_consumed<<"    |"<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;

    cout<<left<<setw(25)<<"|  Cost Per Unit :"<<cost_per_unit<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|  Cost Of Electricity :"<<cost_of_enlectricity<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|  Fuel Price Adjustment :"<<fuel_price_adjustment<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|  F.C Surcharge :"<<FC_Surcharge<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|  QTR Tarrif :"<<QTR_Tarrif<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|  Total 1 :"<<Total1<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|  TV Fee :"<<TV_fee<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|  GST :"<<GST<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|  GST On FPA :"<<GST_ON_FPA<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|  Total 2 :"<<Total2<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|  Current Bill :"<<current_bill<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|  Total FPA :"<<total_FPA<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|  Payable Within Due Date :"<<payable_within_due_date<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|  LP Surcharge :"<<LP_surcharge<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;
    cout<<left<<setw(25)<<"|  Payable After Due Date :"<<payable_after_due_date<<endl;
    cout<<"___________________________________________________________________________________________________"<<endl;

return 0;
}