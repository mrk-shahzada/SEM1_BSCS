#include<iostream>
using namespace std;
int main(){
    for (int i = 6; i >= 0; i--)
    {
        for (int j = i; j >= 1; j--)
        {
            cout<<"*";
        }
         for (int k = 5; k >= i; k--)
        {
            cout<<" ";
        }
   for(int l =1; l<=(2*i); l++){
            cout<<"/";
        }
        for(int m=1; m<=12-(2*i); m++){
            cout<<"\\";
        }
        
        for (int k = 5; k >= i; k--)
        {
            cout<<" ";
        }
        for(int l = i; l>= 1; l--){
            cout<<"*";
        }
        cout<<endl;
    }
return 0;
}