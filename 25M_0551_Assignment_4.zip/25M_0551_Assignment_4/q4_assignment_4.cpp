#include<iostream>
using namespace std;
int main(){
    int n,sum=0;
    cout<<"Enter the size of array :";
    cin>>n;
    int array[n];
    for (int i = 0; i < n ; i++)
    {
       cout<<"Enter number "<<i+1<<" :";
       cin>>array[i];
       sum = sum + array[i];
    }
    
    if (sum % 2 == 0)
    {
        cout<<"\nPair Exists"<<endl;
         for (int i = 0; i < n; i++)
    {
        for (int j = 1+i; j < n; j++){
        
            if(sum/2 == array[i] + array[j]){
        cout<<"Elements are :"<<array[i]<<", "<<array[j];
            }
        }
        
    } 
    }
    else{
        cout<<"\nThe pair does not exist"<<endl;
    }
    
    
      

    
return 0;
}