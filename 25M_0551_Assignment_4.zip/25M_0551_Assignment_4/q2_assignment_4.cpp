#include<iostream>
using namespace std;
int main(){
    int array[10]={1,3, 5, 4, 9, 8, 2, 6, 7, 10};
    int size = 10;
    int n;

    cout<<"Original array :";
    for (int i = 0; i < size; i++)
    {
        cout<<array[i]<<" ";
    }
    cout<<endl;

    while (n<=0 || n>=size)
    {
        cout<<"Enter number for right shift from 1 to "<<size-1<<" :";
        cin>>n;
    }

    while (n>0)
    {
        int last = array[size-1];
        n--;
    
    
    for (int i = size-1; i > 0; i--)
    {
        array[i] = array[i-1];
    }
    array[0] = last;
}
    
    cout<<"\nShifted array :";
    for (int i = 0; i < size; i++)
    {
        cout<<array[i]<<" ";
    }
    cout<<endl;
    
    
return 0;
}