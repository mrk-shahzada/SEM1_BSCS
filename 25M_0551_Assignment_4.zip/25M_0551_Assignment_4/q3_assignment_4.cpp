#include<iostream>
using namespace std;
int main(){
    int n;
    cout<<"Enter a number(10,15 or 20) :";
    cin>>n;
    int arr[n];
    int temp;
    int k,l,small,large,small_index=-1,large_index=-1;
    cout<<"\nEnter a number for largest :";
    cin>>l;
    cout<<"\nEnter a number for smallest :";
    cin>>k;
    for (int i = 0; i < n; i++)
    {
        cout<<"Enter numbers "<<i+1<<" for array :";
        cin>>arr[i];
    }
   
    for (int i = 0; i < n-1; i++)
    {
        for (int j = 0; j < n-i-1; j++)
        {
            if (arr[j]>arr[j+1])
            {
                temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp; 
            }
            
        }
        
    }
    cout<<"Ordered array :";
    for (int i = 0; i < n; i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
    
    large = arr[n-l];
    small = arr[k-1];
    for (int i = 0; i < n; i++)
    {
        if (arr[i] == small && small_index == -1)
        {
            small_index = i;
        }
         if (arr[i] == large && large_index == -1)
        {
            large_index = i;
        }
    }
    
    cout<<k<<"th smallest is "<<small<<" at index "<<small_index<<endl;
    cout<<l<<"th largest is "<<large<<" at index "<<large_index<<endl;
    
    
return 0;
}