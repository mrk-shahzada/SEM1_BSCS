//Muhammad Rowaifa Khan
//25M-0551
//Assignment no 2
#include<iostream>
using namespace std;
int main(){
        int amount, fiveHundredNote, ThousandNote, FiveThousandNote;
        cout<<"Enter the total amount you want to withdraw :";
        cin>>amount;
        if (amount<50000)
        {
              if (amount % 500 != 0){
            cout<<"Enter the amount which must me multiple of 500"<<endl;   
              }
        
            else { fiveHundredNote = 1;
         amount = amount - 500;

         FiveThousandNote = amount/5000;
         amount = amount % 5000;

         ThousandNote = amount/1000;
         amount = amount % 1000;

         fiveHundredNote = amount/500 + fiveHundredNote;


         cout<<"Rs. 5000 Notes: "<<FiveThousandNote<<endl;
         cout<<"Rs. 1000 Notes: "<<ThousandNote<<endl;
         cout<<"Rs. 500 Notes: "<<fiveHundredNote<<endl;
           
         } 
          } 
        else{
                cout<<"You have exceeded your daily limit of Rs. 50,000"<<endl;
        }
            
       
return 0;
}