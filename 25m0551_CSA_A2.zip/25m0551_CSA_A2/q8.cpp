//Muhammad Rowaifa Khan
//25M-0551
//Assignment no 2
#include<iostream>
using namespace std;
int main(){
    int date,month,year;
    cout<<"Enter Date: ";
    cin>>date;
    cout<<"Enter Month: ";
    cin>>month;
    cout<<"Enter Four-Digit Year: ";
    cin>>year;
    year = year%100;
    (date*month == year)?cout<<"The date is magic":cout<<"The date is not magic";
return 0;
}