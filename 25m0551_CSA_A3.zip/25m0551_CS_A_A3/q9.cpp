#include<iostream>
using namespace std;
int main(){
    int excl = 22;
    for (int i = 2; i <= 10; i+=2)
    {
        for (int j = 1; j <= i; j++)
        {
            cout<<"\\";
        }
        for(int j = 1; j<=excl; j++){
            cout<<"!";
        }
        
        for (int m = i; m >= 1; m--)
        {
            cout<<"/";
        }
        excl-=4;
        
        cout<<endl;
    }
    
return 0;
}