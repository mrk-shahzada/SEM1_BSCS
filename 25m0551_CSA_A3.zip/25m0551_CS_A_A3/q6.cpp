#include<iostream>
using namespace std;
int main(){
    int n,r,q,sum=0;
    cout<<"Enter a number: ";
    cin>>n;
    for (int i = 1; i <= 4; i++)
    {
        r = n%10;
        n = n/10;
        cout<<r;
        sum = sum + r;

    }
    cout<<"\nThe sum is: "<<sum;
return 0;
}