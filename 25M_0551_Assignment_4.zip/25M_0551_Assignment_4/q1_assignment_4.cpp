#include <iostream>
using namespace std;

int main() {
    int array[20];
    int UniqueCount = 0;

    int i=0;
    while (i<20)
    {
         cout<<"Enter number "<<i + 1<<": ";
        cin>>array[UniqueCount];   

     
        if (array[UniqueCount] <= 10 || array[UniqueCount] >= 100) {
            cout<<"Invalid input! Enter the number between 10 and 100"<<endl;
            continue;  
        }

        int j;
        for (j = 0; j < UniqueCount; j++) {
            if (array[j] == array[UniqueCount]) {
                break;   
            }
        }

        if (j < UniqueCount) {
            cout<<"Duplicate ignored"<<endl;
            continue;   
        }

        UniqueCount++;
       
        i++;
    }

   
    cout << "\nUnique numbers entered: "<<endl;
    for (int i = 0; i < UniqueCount; i++) {
        cout << array[i] << " ";
    }

    return 0;
}
