#include<iostream>
using namespace std;
int main(){
    int n,marks;
    float sum, mean;
    cout<<"Enter the number of students: ";
    cin>>n;

    for (int i = 1; i <= n; i++)
    {
        cout<<"Enter the marks of student "<<i<<": ";
        cin>>marks;
        sum = sum + marks;
    }
    mean = sum/n;
    cout<<"The mean of the scores of the student is: "<<mean;

return 0;
}