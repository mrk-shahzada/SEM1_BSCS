//Muhammad Rowaifa Khan
//25M-0551
//Assignment no 2
#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
int main(){
    srand(time(0));
    char operation,allocation;
    int max_Value,num1,num2;
    cout<<"For which operation an exercise should be generated(+,-,*,/) :";
    cin>>operation;
    cout<<"Enter the maximum value: ";
    cin>>max_Value;
    cout<<"Are negative values allowed or not?(Y for yes & N for not) ";
    cin>>allocation;

    if (allocation == 'Y' || allocation == 'y')
    {
        num1 = rand() % (2*max_Value+1)-max_Value;
        num2 = rand() % (2*max_Value+1)-max_Value;
    }
    else{
        num1 = rand() % max_Value + 1;
        num2 = rand() % max_Value + 1;
        if (operation == '-')
        {
            
        }
        
    }
    
return 0;
}