//Muhammad Rowaifa Khan
//25M-0551
//Assignment no 2
#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
int main(){
    srand(time(0));
    int n;
    cout<<"Enter a number to choose game\n1.Play Higher or Lower\n2.Play Rock-Paper-Scissors\n3.Guess the Number\n4.Quit Game "<<endl;
    cin>>n;

    if (n == 1)
    {
        char a;
        cout<<"You are playing Higher or Lower game"<<endl;
        int num1 = rand() % 20 + 1;
        int num2 = rand() % 20 + 1;

        cout<<"1st number is: "<<num1<<endl;
        cout<<"Guess the 2nd number is lower or higher: ";
        cin>>a;
        if((a == 'L' || a == 'l')  &&  num2<num1){
            cout<<"You Win!"<<endl;
            cout<<"2nd number is: "<<num2<<endl;
        }
        
        else if((a == 'H' || a == 'h')  &&  num2>num1){
            cout<<"You Win!"<<endl;
            cout<<"2nd number is: "<<num2<<endl;
        }

        else{
            cout<<"You loss!!"<<endl;
            cout<<"2nd number is: "<<num2<<endl;
        }
    }

    else if(n == 2){
        char a;
        cout<<"You are playing Rock-Paper-Scissors"<<endl;
        int num = rand() % 3 + 1;
        cout<<"Enter R for Rock, P for Paper or S for Scissors: ";
        cin>>a;

        if (num == 1 && a == 'P')
        {
            cout<<"No one Win or loss!"<<endl;
        }
        else if (num == 1 && a == 'R')
        {
          cout<<"You loss..!!"<<endl;
        }  
        else if (num == 1 && a == 'S')
        {
          cout<<"You Win!"<<endl;
        } 
        else if (num == 2 && a == 'P')
        {
          cout<<"You Loss..!!"<<endl;
        } 
        else if (num == 2 && a == 'R')
        {
          cout<<"You Win!"<<endl;
        } 
        else if (num == 2 && a == 'S')
        {
          cout<<"No one win or loss"<<endl;
        } 
        else if (num == 3 && a == 'P')
        {
          cout<<"You Win!"<<endl;
        } 
        else if (num == 3 && a == 'R')
        {
          cout<<"No one win or loss"<<endl;
        } 
        else if (num == 3 && a == 'S')
        {
          cout<<"You Loss..!!"<<endl;
        } 
    }
    else if(n == 3){
        cout<<"You are playing Guess Number game"<<endl;
        int num1 = rand() % 10;
        int num2 = rand() % 10;
        int num3 = rand() % 10;
        int a,b,c,match=0;
        cout<<"Enter 1st number(0 to 9): ";
        cin>>a;
        cout<<"Enter 2nd number(0 to 9): ";
        cin>>b;
        cout<<"Enter 3rd number(0 to 9): ";
        cin>>c;

        if (a == num1 || a == num2 || a == num3)
        {
            match++;
        }
        if (b == num1 || b == num2 || b == num3)
        {
            match++;
        }
        if (c == num1 || c == num2 || c == num3)
        {
            match++;
        }
        

        if(a == num1 && b == num2 && c == num3){
            cout<<"All Numbers matched in Exacat order"<<endl;
        }

        if(match == 1){
            cout<<"Only 1 number matched"<<endl;
        }
        else if(match == 2){
            cout<<"Only 2 numbers matched"<<endl;
        }
        else if(match == 3){
            cout<<"All numbers matched but not in exact ordered"<<endl;
        }
        else{
            cout<<"No one matched!"<<endl;
        }
        
        
    }
    else if(n == 4){
        cout<<"You Quit the Game"<<endl;
    }
    else{
        cout<<"Invalid input!"<<endl;
    }
return 0;
}