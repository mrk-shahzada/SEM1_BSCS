//Muhammad Rowaifa Khan
//25M-0551
//Assignment no 2
#include<iostream>
using namespace std;
int main(){
    int n;
    cout<<"Enter a 16 bit number :";
    cin>>n;
return 0;
}