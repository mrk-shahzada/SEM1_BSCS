#include<iostream>
using namespace std;
int main(){
    int n;
    cout<<"Enter the number of lines you want to print: ";
    cin>>n;

   int i =1;
   while (i<=n)
   {
    int j = 1;
    while (j<=6)
    {
        int k = 1;
        while (k<=10)
        {
            int a = k;
            if(k == 10){
                a = 0;
            }
            cout<<a;
            k++;
        }
        
        j++;
    }
    cout<<endl;
    i++;
  }
return 0;
}