#include<iostream>
using namespace std;
int main(){
    int n;
    for (int i = 1; i <= 40; i++)
    {
        cout<<"-";
    }
    cout<<endl;
    for (int j = 1; j <= 10; j++)
    {
        cout<<"_-^-";
    }
    cout<<endl;

    for (int k = 1; k <= 2; k++)
    {
        for (int l = 1; l <= 10; l++)
        {
            n = l%10;
            cout<<n<<n;
        }
    }
    cout<<endl;
    for (int i = 1; i <= 40; i++)
    {
        cout<<"-";
    }
    cout<<endl;
return 0;
}