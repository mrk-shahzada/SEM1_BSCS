#include<iostream>
using namespace std;
int main(){
    int n,m,r;
    cout<<"Enter 1st number: ";
    cin>>n;
    cout<<"Enter 2nd number: ";
    cin>>m;

    while (n!=0)
    {
        r = m%n;
        m = n;
        n = r;
    }
    cout<<"Greatest common Divisor is: "<<m<<endl;
    
return 0;
}