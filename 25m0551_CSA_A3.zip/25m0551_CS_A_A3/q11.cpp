#include<iostream>
using namespace std;
int main(){
  

    int i = 1;
    while (i<=5)
    {
        int j = 4;
        while (j>=i)
        {
            cout<<" ";
            j--;
        }
        int k = 1;
        while (k<=i)
        {
            cout<<i;
            k++;
        }
        
        i++;
        cout<<endl;
    }
return 0;
}   