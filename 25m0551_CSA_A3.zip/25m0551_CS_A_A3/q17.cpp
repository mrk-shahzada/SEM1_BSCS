#include<iostream>
using namespace std;
int main(){
    int denomi = 2;
    int nume ;
    while (denomi <= 32)
    {
        nume = denomi -1;
        cout<<denomi - 1 <<"/"<<denomi <<",";
        denomi = denomi * 2;
    }
    cout<<"... ... ..."<<endl;
    
return 0;
}