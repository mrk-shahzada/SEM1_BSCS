//Muhammad Rowaifa Khan
//25M-0551
//Assignment no 2
#include<iostream>
#include<cmath>
using namespace std;
int main(){
        float u = 1.234, p = 3.334;
        float i;
        float step1,step2,step3,step4,step5,step6,step7,step8,step9,step10,step11;
        cout<<"Enter the value of i :";
        cin>>i;

        step1 = pow(i,1.5);
        step2 = u*step1;
        step3 = pow(i,2) - 1;
        step4 = step2 * step3;
        step5 = sqrt(step4);
        step6 = p*i - 2;
        step7 = sqrt(step6);
        step8 = p*i - 1;
        step9 = sqrt(step8);
        step10 = step7 + step9;
        step11 = step5/step10;

        cout<<"Your answer is: "<<step11;


return 0;
}