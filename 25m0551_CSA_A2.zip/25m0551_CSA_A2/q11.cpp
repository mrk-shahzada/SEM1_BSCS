//Muhammad Rowaifa Khan
//25M-0551
//Assignment no 2
#include<iostream>
using namespace std;
int main(){
    char a;
    cout<<"Starting General Diagnosis Program"<<endl;
    cout<<"(1)Recording Symptom Information"<<endl;
    cout<<"Done"<<endl;
    cout<<"Rebooting Server to see if condition still exists"<<endl;
    cout<<"Done"<<endl;
    cout<<"Is this a newly installed Server?(Y/N)";
    cin>>a;
    if(a=='Y'){
        cout<<"(2)Please Reset any components that may have come loose during shipping and reboot the Server "<<endl;
        cout<<"Done"<<endl;
        cout<<"Does the condition still exists?";
        cin>>a;
        if(a=='N'){
            cout<<"(1)Record action Taken"<<endl;
            cout<<"Done"<<endl;
            cout<<"Congratulations, your server problems are solved"<<endl;
        }
        else if(a == 'Y'){
            goto next_step1;
        }
    }
    next_step1:
    if(a == 'N' || a == 'Y'){
        cout<<"Were options added or was the configuration changed recently?";
        cin>>a;
            if(a == 'Y'){
                cout<<"(6)Isolating what has changed. Verifying i was installed correctly. Restoring Sever to last known working state or original shipped configuration"<<endl;
                cout<<"Done"<<endl;
                cout<<"Does the condition still exists?";
                cin>>a;
                if(a == 'Y'){
                    goto next_step2;
                }
                if(a == 'N'){
                    cout<<"(1)Recording Action Taken"<<endl;
                    cout<<"Congratulations Your server problems are solved"<<endl;
                }
            }
             if(a == 'N'){
                cout<<"(3)Checking for service Notification"<<endl;
                cout<<"Done"<<endl;
                cout<<"Downloading the latest software and firmware from the HP Website "<<endl;
                cout<<"Done"<<endl;
                cout<<"Does condition still exists?";
                cin>>a;
                if(a == 'N'){
                    cout<<"(1)Recording Action Taken"<<endl;
                    cout<<"Congratulations Your server problems are solved"<<endl;
                }
                next_step2:
                if(a == 'Y'){
                    cout<<"(5)Isolate and minimize the memory configuration"<<endl;
                    cout<<"Done"<<endl;
                    cout<<"Does condition still exists?";
                    cin>>a;
                    if(a == 'N'){
                    cout<<"(1)Recording Action Taken"<<endl;
                    cout<<"Congratulations Your server problems are solved"<<endl;
                    }
                    if(a == 'Y'){
                        cout<<"Breaking server down to minimal configuration"<<endl;
                        cout<<"Done"<<endl;
                        cout<<"Does condition still exists?";
                        cin>>a;
                        if(a == 'N'){
                            cout<<"(6)Adding one part at a time back to configuration to isolate faulty component"<<endl;
                            cout<<"Done"<<endl;
                            cout<<"Does the condition still exists?";
                            cin>>a;
                            if(a == 'N'){
                                 cout<<"(1)Recording Action Taken"<<endl;
                                 cout<<"Congratulations Your server problems are solved"<<endl;
                            }
                            if(a == 'Y'){
                                goto next_step3;
                            }
                        }
                        if(a == 'Y'){
                            cout<<"(7)Troubleshooting or replacing basic server spare parts"<<endl;
                            cout<<"Done"<<endl;
                            cout<<"Does the condition still exists?";
                            cin>>a;
                            next_step3:
                            if(a == 'Y'){
                                cout<<"(8)Ensure the following information is available:\n1.Survey configuration snapshots\n2.OS Event log file\n3.Full crash dump"<<endl;
                                cout<<"Done"<<endl;
                                cout<<"Call HP Sevice Provider"<<endl;
                            }
                            if(a == 'N'){
                                cout<<"Recording Symptom and error information on repair tag if sending back a failed part"<<endl;
                                cout<<"Done"<<endl;
                                cout<<"Congratulations Your server problems are solved"<<endl;
                            }
                        }
                    }
                }
            }
    }

return 0;
}