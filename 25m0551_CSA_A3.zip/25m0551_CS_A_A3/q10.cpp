#include<iostream>
using namespace std;
int main(){
   
    int i = 1;
    while (i<=6)
    { 
        int j = 1;
        while (j<=2)
        {
            cout<<"#";
            int k =1;
            while (k<i)
            {
                cout<<" ";
                k++;
            }
            
            j++;
        }
        
        i++;
        cout<<endl;
    }
return 0;
}